import { Router } from "express";
const router = Router();

router.get("/", (req, res) => res.render("index", {title:'WebSite_Node'}));

router.get("/consultaOrden", (req, res) => res.render("consultaOrden", {title:'Consultar Orden'}));

router.get("/crearOrden", (req, res) => res.render("crearOrden", {title:'Crear Orden'}));

router.get("/listarOrden", (req, res) => res.render("listarOrden", {title:'Listar Orden'}));

export default router;
